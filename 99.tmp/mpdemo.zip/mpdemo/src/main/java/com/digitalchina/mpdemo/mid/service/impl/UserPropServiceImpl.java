package com.digitalchina.mpdemo.mid.service.impl;

import com.digitalchina.mpdemo.mid.entity.UserProp;
import com.digitalchina.mpdemo.mid.mapper.UserPropMapper;
import com.digitalchina.mpdemo.mid.service.UserPropService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 登陆过系统的用户 服务实现类
 * </p>
 *
 * @author lichunlong
 * @since 2019-10-10
 */
@Service
public class UserPropServiceImpl extends ServiceImpl<UserPropMapper, UserProp> implements UserPropService {

}
