package com.digitalchina.mpdemo.mid.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 登陆过系统的用户
 * </p>
 *
 * @author lichunlong
 * @since 2019-10-10
 */
@TableName("user_prop")
@ApiModel(value="UserProp对象", description="登陆过系统的用户")
public class UserProp implements Serializable {

    private static final long serialVersionUID = 1L;

        @ApiModelProperty(value = "用户ID")
        private Integer id;

        @ApiModelProperty(value = "属性名")
        private String prop;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProp() {
        return prop;
    }

    public void setProp(String prop) {
        this.prop = prop;
    }

    public static final String ID = "id";

    public static final String PROP = "prop";

    @Override
    public String toString() {
        return "UserProp{" +
        "id=" + id +
        ", prop=" + prop +
        "}";
    }
}
