package com.digitalchina.mpdemo.mid.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 登陆过系统的用户 前端控制器
 * </p>
 *
 * @author lichunlong
 * @since 2019-10-10
 */
@RestController
@RequestMapping("/userProp")
public class UserPropController {

}

