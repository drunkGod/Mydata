package com.digitalchina.mpdemo.mid.service;

import com.digitalchina.mpdemo.mid.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 登陆过系统的用户 服务类
 * </p>
 *
 * @author lichunlong
 * @since 2019-10-10
 */
public interface UserService extends IService<User> {

}
