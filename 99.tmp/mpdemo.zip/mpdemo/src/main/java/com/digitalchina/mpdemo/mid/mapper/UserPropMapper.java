package com.digitalchina.mpdemo.mid.mapper;

import com.digitalchina.mpdemo.mid.entity.UserProp;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 登陆过系统的用户 Mapper 接口
 * </p>
 *
 * @author lichunlong
 * @since 2019-10-10
 */
public interface UserPropMapper extends BaseMapper<UserProp> {

}
