<template>
	<div>
		It is in vueBBBB.
				<p><router-link to="/">返回</router-link></p>
				
	</div>
</template>

<script>
</script>

<style>
</style>