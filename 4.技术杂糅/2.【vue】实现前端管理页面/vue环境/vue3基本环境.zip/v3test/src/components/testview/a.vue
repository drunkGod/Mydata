<template>
	<div>
		It is in vueAAAA.
		<p><router-link to="/a1">前往子页</router-link></p>
		<p><router-link to="/">返回首页</router-link></p>
		<router-view></router-view>
	</div>
</template>

<script>
</script>

<style>
</style>