<template>
	<div>
		It is in vueA'son：vueA11111'.
		<p><router-link to="/a">返回上一级</router-link></p>
		<p><router-link to="/">返回首页</router-link></p>

	</div>
</template>

<script>
</script>

<style>
</style>