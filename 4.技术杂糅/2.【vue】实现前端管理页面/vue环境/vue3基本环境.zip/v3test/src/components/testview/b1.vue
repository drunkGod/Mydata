<template>
	<div>
		It is in vueB's son 1'.
		<p><router-link to="/">返回</router-link></p>

	</div>
</template>

<script>
</script>

<style>
</style>