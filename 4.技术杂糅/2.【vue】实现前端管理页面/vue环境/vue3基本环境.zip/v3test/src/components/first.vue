<template>
	<div class="firstStyle">
	It is my fist vue page
	<div>
		<router-link to="A">TO A</router-link>
		<br>
		<router-link to="B">TO B</router-link>
	</div>
	</div>

	
</template>

<script>
	
</script>

<style>
	.firstStyle {
		color: red;
	}
</style>